# Budget Allocation

Starting budget: $200.

- $0 Payhip Free plan for storefront validation.
- $15-$20 domain after the first sale or once the Payhip page is live.
- $20 Etsy listing test only after Canva template links are created; publish 10 listings at $0.20 each plus room for renewal tests.
- $29 Canva Pro for one month if needed to convert SVGs into Canva template links and polish mockups.
- $15 Tailwind or Pinterest scheduler for the first month only after storefront is live.
- $50 micro-influencer or creator newsletter test after the first conversion-ready listing is live.
- $75 reserve for promoted pins or Etsy ads only after organic pins/listings show saves, clicks, or favorites.

Default rule: no paid traffic until the product page, checkout, and delivery are verified.
