# Required Owner Step-Ins

## Now

1. Create or approve a Payhip account and connect Stripe or PayPal for payouts.
2. Connect Canva if you want the templates converted into true Canva share links.
3. Approve the shop name if QuietLaunch Studio conflicts with an existing preference.

## Before first paid traffic

1. Make one test purchase or 100% off coupon redemption to verify checkout and delivery.
2. Confirm refund policy and commercial-use terms.
3. Approve any paid ad spend.

## Weekly, under 30 minutes

1. Check sales, visits, conversion rate, and top traffic source.
2. Approve one product improvement or one new listing variant.
3. Reply to any customer message that needs owner judgment.
