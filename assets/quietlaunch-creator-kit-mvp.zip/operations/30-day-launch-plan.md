# 30-Day Launch Plan

## Week 1

- Launch Payhip page with QuietLaunch Creator Kit.
- Upload product ZIP and listing images.
- Post 15 Pinterest pins across 5 focused boards.
- Publish 3 short-form videos using the included hooks and cover assets.
- Send launch email if a list exists; otherwise publish the opt-in copy as product-page copy.

## Week 2

- Create Etsy shop/listing only if Canva template links are ready.
- Add 10 more pins using alternate titles.
- Create a $19 launch coupon for first 20 buyers.
- Review traffic and conversion numbers.

## Week 3

- Turn the best-performing template category into a second mini SKU.
- Test one creator partnership or newsletter placement under $50.
- Add FAQs and stronger mockups based on visitor questions.

## Week 4

- Raise price from $19 to $29 unless conversion is below 1%.
- Bundle the original kit plus mini SKU into a $49 QuietLaunch Vault waitlist.
- Decide whether to add Etsy ads, promoted pins, or stay organic for another cycle.
