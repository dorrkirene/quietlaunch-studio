# Storefront Listing Copy

## Listing title

QuietLaunch Creator Kit, Soft Neutral Canva-Ready Social Media Templates, Creator Brand Kit, Pinterest Pins, Reels Covers, Media Kit, Launch Checklist

## Short description

A soft neutral launch kit for creators and small brands who want polished marketing assets without starting from a blank page. Includes editable SVG templates, PNG previews, Pinterest pins, short-form covers, a media kit cover, launch checklist, 30-day content calendar, and copy prompts.

## Price

Launch price: $19 for first 20 customers. Regular price: $29. Bundle anchor for future catalog: $49 for the complete QuietLaunch Vault once 3 kits exist.

## What’s included

- 10 editable social, launch, and creator brand templates
- Instagram post, carousel, testimonial, offer stack, and opt-in promo layouts
- Reels and short-form cover layouts
- Pinterest pin templates and launch pin assets
- Media kit cover and launch checklist layouts
- 30-day launch content calendar
- Caption, email subject, and product copy bank

## Who it’s for

Content creators, digital product sellers, coaches, consultants, newsletter writers, brand photographers, social media managers, and small brands who want a polished launch presence without a custom design budget.

## SEO tags

canva social media templates, creator media kit, pinterest pin templates, instagram templates, brand kit template, launch checklist, digital product templates, creator templates, small business templates, soft neutral templates, content calendar, reels cover template, launch kit, media kit template, aesthetic templates

## Buyer FAQ

Q: Is this a Canva template?
A: The MVP includes editable SVG templates and PNG previews. Canva template links should be added after Canva is connected, but buyers can import and customize the SVG files in Canva or another editor.

Q: Can I use these for client work?
A: Yes, buyers may use the finished exported designs for their own brand or client projects. They may not resell, redistribute, or claim the source templates as their own.

Q: Do I need design software?
A: Canva, Figma, Adobe Express, Affinity Designer, or another SVG-friendly editor is recommended.
