# Launch Email Sequence

## Email 1: New product announcement
Subject: A softer way to launch
Preview: The QuietLaunch Creator Kit is live.

Your next offer does not need to look louder. It needs to look clearer.

The QuietLaunch Creator Kit is a soft neutral bundle of creator launch assets: social templates, Pinterest pins, short-form covers, a media kit cover, launch checklist, 30-day content calendar, and copy prompts.

It is built for the moment when your product, service, opt-in, or newsletter is ready enough, but your launch visuals still feel scattered.

Launch price: $19 for the first 20 customers. Regular price: $29.

CTA: Get the QuietLaunch Creator Kit

## Email 2: Use-case education
Subject: Your brand can look ready today
Preview: Start with one offer and one template system.

If you have a creator offer, you do not need a full rebrand to launch. You need a cohesive handful of assets that make every touchpoint feel intentional.

Use the kit to make a lead magnet promo, launch carousel, Pinterest traffic pin, testimonial card, and short-form cover in one sitting.

CTA: Start with the creator kit

## Email 3: Last-call urgency
Subject: Last call for the launch price
Preview: The $19 launch price ends after 20 customers.

The QuietLaunch Creator Kit moves to $29 after the first 20 customers. If you want the soft neutral templates, 30-day content calendar, and launch copy bank at the intro price, now is the right time.

CTA: Get it before the price changes
