# Pinterest and Short-Form Launch Plan

## Pinterest boards

- Creator Brand Kit Ideas
- Soft Neutral Social Media Templates
- Digital Product Launch Checklist
- Pinterest Templates for Small Business
- Content Creator Media Kit Templates

## Pin titles

1. Soft Neutral Creator Brand Kit Templates
2. Creator Launch Checklist for Digital Products
3. Pinterest Pin Templates for Small Brands
4. Aesthetic Reels Cover Templates for Creators
5. Done-for-You Digital Product Launch Assets
6. Minimal Media Kit Template for Content Creators
7. Instagram Carousel Templates for Selling Softly
8. Brand Refresh Kit for Solo Creators
9. Content Calendar for a 30-Day Launch
10. Soft Neutral Templates for Coaches and Creators

## Short-form hooks

- Your launch does not need to be louder. It needs to be clearer.
- Three assets I would make before posting a new offer.
- If your brand feels almost ready, do this 10-minute reset.
- What I would put inside a one-page creator media kit.
- The easiest way to make Pinterest and Instagram look cohesive.
