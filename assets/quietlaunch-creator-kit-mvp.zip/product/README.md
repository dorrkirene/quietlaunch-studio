# QuietLaunch Creator Kit

## What this is

QuietLaunch Creator Kit is a soft neutral digital launch kit for creators, solo service providers, coaches, newsletter writers, digital product sellers, and small brands. It is designed to help a buyer make their next launch look polished quickly, without hiring a designer.

## Included files

- 10 editable SVG source templates in `editable-svg-templates/`
- 10 exported PNG previews in `png-previews/`
- 5 storefront/listing images in the launch assets folder
- 5 Pinterest and short-form social launch assets
- 30-day content calendar CSV
- Copy bank with captions, subject lines, and product positioning

## How buyers customize it

1. Open the SVG template in Canva, Figma, Adobe Express, Affinity Designer, or another editor that supports SVG imports.
2. Replace the placeholder headline, subtitle, and call to action with their offer copy.
3. Swap colors using the palette below or their own brand colors.
4. Export as PNG or JPG and publish.

## Brand palette

{
  "oat": "#F4EFE7",
  "linen": "#FBF8F2",
  "ink": "#26211B",
  "clay": "#A9826D",
  "moss": "#6F7564",
  "taupe": "#D9CBBF",
  "espresso": "#4B4038"
}

## Canva conversion note

For the highest-converting storefront version, convert the SVG templates into Canva template links after connecting Canva. The current MVP is still sellable as an editable SVG + PNG + guide bundle, but Canva links are the fastest trust signal on Etsy.
